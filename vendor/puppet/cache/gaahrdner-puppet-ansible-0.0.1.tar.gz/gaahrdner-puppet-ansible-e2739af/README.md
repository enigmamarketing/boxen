# Ansible module for Boxen

This module will install [Ansible](https://github.com/ansible/ansible) via
[homebrew](http://brew.sh/).

Blasphemers rejoice!

[![Build Status](https://travis-ci.org/gaahrdner/puppet-ansible.png?branch=master)](https://travis-ci.org/gaahrdner/puppet-ansible)

## Usage

```puppet
  include ansible
```

## Required Puppet Modules

* `boxen`
* `homebrew`
